<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>403 - Forbidden</title>
</head>
<body>
    <h1>403</h1>
    <p>You do not have permission to view this page.</p>
    <a href="{{route('login')}}">Go to Login</a>
</body>
</html>
